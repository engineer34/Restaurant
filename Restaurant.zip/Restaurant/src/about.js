export default function loadAbout() {
    const content = document.getElementById("content");
    content.textContent = "Info on items";
}