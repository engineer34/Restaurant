export default function loadHome() {
    const content = document.getElementById("content");
    content.textContent = "Welcome to my restaurant!";
}