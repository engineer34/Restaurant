import loadHome from "./home.js";
//importing our functions and adding 
// eventlisteners when we click on home menu or about
import loadMenu from "./menu.js";
import loadAbout from "./about.js";
document.getElementById("home").addEventListener("click", loadHome);
document.getElementById("menu").addEventListener("click", loadMenu);
document.getElementById("about").addEventListener("click", loadAbout);
//my default page is home
loadHome();