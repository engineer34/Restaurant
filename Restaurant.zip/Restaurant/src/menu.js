export default function loadMenu() {
    const content = document.getElementById("content");
    content.textContent = "Menu items here";
}